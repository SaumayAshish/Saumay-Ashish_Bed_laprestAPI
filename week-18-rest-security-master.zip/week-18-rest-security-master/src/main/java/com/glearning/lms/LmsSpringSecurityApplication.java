package com.glearning.lms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmsSpringSecurityApplication.class, args);
	}

}
